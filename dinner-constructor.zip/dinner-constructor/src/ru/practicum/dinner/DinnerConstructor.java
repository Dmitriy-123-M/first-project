package ru.practicum.dinner;

import java.util.HashMap;
import java.util.ArrayList;
import java.util.Random;

public class DinnerConstructor {
    HashMap<String, ArrayList<String>> menu = new HashMap<>();
    Random random = new Random();

    public void dinnerGenerator(ArrayList<String> dishTypes) {
        ArrayList<String> generatedSetOfDishes = new ArrayList<>();
        for (String dish : dishTypes) {
            generatedSetOfDishes.add(menu.get(dish).get(random.nextInt(menu.get(dish).size())));
        }
        System.out.println(generatedSetOfDishes);
    }

}


