package ru.practicum.dinner;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {

    static DinnerConstructor dinnerConstructor;
    static Scanner scanner;

    public static void main(String[] args) {
        dinnerConstructor = new DinnerConstructor();
        scanner = new Scanner(System.in);

        while (true) {
            printMenu();
            String command = scanner.nextLine();

            switch (command) {
                case "1":
                    addNewDish();
                    break;
                case "2":
                    generateDishCombo();
                    break;
                case "3":
                    return;
            }
        }
    }

    private static void printMenu() {
        System.out.println("Выберите команду:");
        System.out.println("1 - Добавить новое блюдо");
        System.out.println("2 - Сгенерировать комбинации блюд");
        System.out.println("3 - Выход");
    }

    private static void addNewDish() {
        System.out.println("Введите тип блюда:");
        String dishType = scanner.nextLine();
        System.out.println("Введите название блюда:");
        String dishName = scanner.nextLine();

        if (dinnerConstructor.menu.containsKey(dishType)) {
            dinnerConstructor.menu.get(dishType).add(dishName);
        } else {
            ArrayList<String> newList = new ArrayList<>();
            newList.add(dishName);
            dinnerConstructor.menu.put(dishType, newList);
        }
        // добавьте новое блюдо
    }

    private static void generateDishCombo() {
        System.out.println("Начинаем конструировать обед...");

        System.out.println("Введите количество наборов, которые нужно сгенерировать:");
        int numberOfCombos = scanner.nextInt();
        scanner.nextLine();

        System.out.printf("Вводите типы блюда, разделяя символом переноса строки (enter).\n" +
                " Для завершения ввода введите пустую строку");
        String nextItem = scanner.nextLine();

        ArrayList<String> dishTypes = new ArrayList<>();
        //реализуйте ввод типов блюд
        while (!nextItem.isEmpty()) {
            if (!dinnerConstructor.menu.containsKey(nextItem)){
                System.out.println("Такого типа блюд нет в меню. Введите другой тип.");
            } else {
                dishTypes.add(nextItem);
            }
            nextItem = scanner.nextLine();
        }
        // сгенерируйте комбинации блюд и выведите на экран
        for (int i = 1; i <=  numberOfCombos; i++) {
            System.out.println("Комбо " + i);
            dinnerConstructor.dinnerGenerator(dishTypes);
        }
    }
}
